#include "Jeu.h"
#include <iostream>
using namespace std;

//--------------------------------------------------------------
int main() {

  Jeu monjeu;

  // boucle de jeu, s'arrete a la fin de la partie
  
      monjeu.joue();
}
 