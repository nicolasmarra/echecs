var searchData=
[
  ['getcouleur_184',['getCouleur',['../d5/df0/classPiece.html#a5abbf43c186befaaa07ad6219ba1bd3d',1,'Piece']]],
  ['getdeplace_185',['getDeplace',['../d5/df0/classPiece.html#aded2508d0c7d0e43fd7b9508a0150ed6',1,'Piece']]],
  ['getdouble_5fpas_186',['getDouble_pas',['../db/da4/classPion.html#a44414a37ccb37fdebcb4b5f391f42c85',1,'Pion']]],
  ['getpiece_187',['getPiece',['../d3/d05/classEchiquier.html#adcd303c0249e872ba2a9a7ba74631aaf',1,'Echiquier']]],
  ['getposition_188',['getPosition',['../d5/df0/classPiece.html#a651a9c3ced42926319c07887ed410196',1,'Piece']]],
  ['getroi_189',['getRoi',['../d3/d05/classEchiquier.html#a655af993438ca19587c21cdd1298d625',1,'Echiquier']]],
  ['getx_190',['getX',['../d3/d72/classSquare.html#ab230deeb6845356ffd162a967d205eac',1,'Square']]],
  ['gety_191',['getY',['../d3/d72/classSquare.html#a3b63de9d7d779fa8ba202a85c322c3ac',1,'Square']]]
];
