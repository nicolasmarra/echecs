var searchData=
[
  ['readme_2emd_85',['Readme.md',['../d7/dab/Readme_8md.html',1,'']]],
  ['roi_86',['Roi',['../d5/dac/classRoi.html',1,'Roi'],['../d5/dac/classRoi.html#a59472d2bbccfd805e398a7bff2a81738',1,'Roi::Roi(Couleur couleur, string nom, Square position)'],['../d5/dac/classRoi.html#aa9a2e2b23eb7d7e43301e270fefc2e43',1,'Roi::Roi(Couleur couleur, Square position)'],['../d5/dac/classRoi.html#abc7cae1aaf598b692c8a29b9e6e468cd',1,'Roi::Roi(Square position)']]],
  ['roiblanc_87',['roiBlanc',['../d3/d05/classEchiquier.html#a378f410334564b8472e5fb1f3684403f',1,'Echiquier']]],
  ['roinoir_88',['roiNoir',['../d3/d05/classEchiquier.html#affe1adf233c1bf21b6574b0f2ca3b0a7',1,'Echiquier']]]
];
