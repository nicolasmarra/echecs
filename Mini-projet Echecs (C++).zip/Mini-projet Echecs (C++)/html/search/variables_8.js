var searchData=
[
  ['x_241',['x',['../d3/d72/classSquare.html#a2d73bbd2e669a20d454f811692a288ee',1,'Square']]]
];
