var searchData=
[
  ['4_2dill_2dbishop_2d1_2etxt_128',['4-ill-bishop-1.txt',['../d9/d20/4-ill-bishop-1_8txt.html',1,'']]],
  ['4_2dill_2dknight_2d1_2etxt_129',['4-ill-knight-1.txt',['../d8/de1/4-ill-knight-1_8txt.html',1,'']]],
  ['4_2dill_2dpawn_2d1_2etxt_130',['4-ill-pawn-1.txt',['../dd/d5c/4-ill-pawn-1_8txt.html',1,'']]],
  ['4_2dill_2drook_2d1_2etxt_131',['4-ill-rook-1.txt',['../d1/d43/4-ill-rook-1_8txt.html',1,'']]],
  ['4_2dleg_2dbish_2dknight_2etxt_132',['4-leg-bish-knight.txt',['../d2/d4a/4-leg-bish-knight_8txt.html',1,'']]],
  ['4_2dleg_2dbishop_2d1_2etxt_133',['4-leg-bishop-1.txt',['../d7/dc1/4-leg-bishop-1_8txt.html',1,'']]],
  ['4_2dleg_2dknight_2d1_2etxt_134',['4-leg-knight-1.txt',['../da/d69/4-leg-knight-1_8txt.html',1,'']]],
  ['4_2dleg_2dpawn_2d1_2etxt_135',['4-leg-pawn-1.txt',['../d6/dbc/4-leg-pawn-1_8txt.html',1,'']]]
];
