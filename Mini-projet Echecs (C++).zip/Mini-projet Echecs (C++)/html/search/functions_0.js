var searchData=
[
  ['affiche_166',['affiche',['../d3/d05/classEchiquier.html#af22265120d527dfb2fa91187c4ce01cf',1,'Echiquier::affiche()'],['../d1/de1/classJeu.html#a7931f8054847abc19e33e73967a3807e',1,'Jeu::affiche()']]],
  ['alloc_5fmem_5fechiquier_167',['alloc_mem_echiquier',['../d3/d05/classEchiquier.html#af0b47dd985820c255f9bba385dc101bc',1,'Echiquier']]]
];
