var searchData=
[
  ['roi_203',['Roi',['../d5/dac/classRoi.html#a59472d2bbccfd805e398a7bff2a81738',1,'Roi::Roi(Couleur couleur, string nom, Square position)'],['../d5/dac/classRoi.html#aa9a2e2b23eb7d7e43301e270fefc2e43',1,'Roi::Roi(Couleur couleur, Square position)'],['../d5/dac/classRoi.html#abc7cae1aaf598b692c8a29b9e6e468cd',1,'Roi::Roi(Square position)']]]
];
