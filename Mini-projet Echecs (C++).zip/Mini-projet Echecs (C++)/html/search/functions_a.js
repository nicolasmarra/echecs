var searchData=
[
  ['saisie_5fcorrecte_204',['saisie_correcte',['../d1/de1/classJeu.html#a81ec468a5a1498dac07cf0a6e6c09c76',1,'Jeu']]],
  ['saisie_5fcorrecte_5fgrandroque_205',['saisie_correcte_grandroque',['../da/dc2/Jeu_8cc.html#a217e727d624f94ec09f6cc183780632c',1,'Jeu.cc']]],
  ['saisie_5fcorrecte_5fpetitroque_206',['saisie_correcte_petitroque',['../d1/de1/classJeu.html#a5c22a435d72e63589785ea15dea28de5',1,'Jeu']]],
  ['setcouleur_207',['setCouleur',['../d5/df0/classPiece.html#aa92070a0da9f20e802bf3735cd1f132c',1,'Piece']]],
  ['setdeplace_208',['setDeplace',['../d5/df0/classPiece.html#af9bdce9f54d2aa7edd794f521f5ca086',1,'Piece']]],
  ['setdouble_5fpas_209',['setDouble_pas',['../db/da4/classPion.html#aa8cc2d8aaa54755a5019ed6fc73d0dc7',1,'Pion']]],
  ['setposition_210',['setPosition',['../d5/df0/classPiece.html#a3e430adecd768f8eb615ffb1fe6ab80e',1,'Piece']]],
  ['setroi_211',['setRoi',['../d3/d05/classEchiquier.html#aa2b858a0a746a5d680447623fa31389b',1,'Echiquier']]],
  ['setsquare_212',['setSquare',['../d3/d72/classSquare.html#adb60dc94ccff8cc3549a949c69d22b8a',1,'Square::setSquare(int x, int y)'],['../d3/d72/classSquare.html#a8b3306436af0eeb4d63f8db692fc0096',1,'Square::setSquare(Square const &amp;square)']]],
  ['square_213',['Square',['../d3/d72/classSquare.html#a3dc7ff9aefc2725172b5d3153973d243',1,'Square::Square()'],['../d3/d72/classSquare.html#a565be7adce7d14e24b908535afa9204b',1,'Square::Square(int x, int y)'],['../d3/d72/classSquare.html#a924a4a0638ce85c91fe85979efb50beb',1,'Square::Square(string position)']]]
];
