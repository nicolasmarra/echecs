var searchData=
[
  ['deplace_227',['deplace',['../d5/df0/classPiece.html#ade7667fac19cb0ccd7068f70fe74f955',1,'Piece']]],
  ['double_5fpas_228',['double_pas',['../db/da4/classPion.html#abdee58a15d1604b3c723099582baa4b3',1,'Pion']]]
];
