var searchData=
[
  ['fischer_2dspassky_2etxt_147',['fischer-spassky.txt',['../d0/d8c/fischer-spassky_8txt.html',1,'']]]
];
