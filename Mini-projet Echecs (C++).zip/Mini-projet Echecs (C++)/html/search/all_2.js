var searchData=
[
  ['6_2dill_2dmove_2dafter_2dchess_2etxt_10',['6-ill-move-after-chess.txt',['../d7/d9b/6-ill-move-after-chess_8txt.html',1,'']]],
  ['6_2dill_2droque_2d1_2etxt_11',['6-ill-roque-1.txt',['../d2/da2/6-ill-roque-1_8txt.html',1,'']]],
  ['6_2dleg_2dpawn_2dpassing_2etxt_12',['6-leg-pawn-passing.txt',['../dd/d3d/6-leg-pawn-passing_8txt.html',1,'']]],
  ['6_2dleg_2droque_2d1_2etxt_13',['6-leg-roque-1.txt',['../db/d3f/6-leg-roque-1_8txt.html',1,'']]],
  ['6_2dleg_2droque_2d2_2etxt_14',['6-leg-roque-2.txt',['../d0/d34/6-leg-roque-2_8txt.html',1,'']]]
];
