var searchData=
[
  ['coup_2etxt_143',['coup.txt',['../d8/d15/coup_8txt.html',1,'']]]
];
